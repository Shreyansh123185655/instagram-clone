import { Loader } from "lucide-react";
import React from "react";

const Fallback = () => {
  return (
    <div>
      <Loader />
    </div>
  );
};

export default Fallback;
