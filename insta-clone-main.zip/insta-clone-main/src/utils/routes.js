export const routes = {
  Signin: "/signin",
  Signup: "/signup",
  Home: "home",
  Root: "/",
  Any: "*",
};
