// @ts-nocheck
import brrokCagle from "./brook-cagle.jpg";
import micahelDam from "./michael-dam.jpg";
import bruceMars from "./bruce-mars.jpg";
import socialGril from "./social-girl.jpg";

export default {
  brrokCagle,
  micahelDam,
  bruceMars,
  socialGril,
};
